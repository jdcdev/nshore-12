====================
Nshore Customization
====================

* Add Credit Limit and allow overlimit in Contact > Invoice tab



