
from . import customer_statement_unmail
from . import partner
from . import invoice
from . import product_template
from . import sale
